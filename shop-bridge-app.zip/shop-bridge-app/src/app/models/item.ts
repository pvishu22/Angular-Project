export interface item{
    Id?:number;
    Name:string;
    Description?:string;
    Price:number;
    ImageUrl?:string;
}